package com.nhnacademy.gw1.sender;

import com.nhnacademy.gw1.Customer;

public interface MessageSender {
    boolean sendMessage(Customer customer, String message);
}
