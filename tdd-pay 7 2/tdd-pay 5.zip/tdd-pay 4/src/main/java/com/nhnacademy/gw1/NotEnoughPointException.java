package com.nhnacademy.gw1;

public class NotEnoughPointException extends RuntimeException{
    public NotEnoughPointException(long point){
        super("Not Enough Point: " + point);
    }
}
