package com.nhnacademy.gw1;

import java.util.Objects;

public class PaymentService {
    private final CustomerRepository customerRepository;

    public PaymentService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    /**
     * 결제처리
     *
     * @param amount     결재 금액
     * @param customerId 고객 아이디
     * @return 영수증
     */
    public Receipt pay(long amount, Long customerId) {

        System.out.println(amount);
        if(amount <= 0){
            throw new InvalidAmountException(amount);
        }

        Customer customer = customerRepository.findById(customerId);
        if (customer == null) {
            throw new CustomerNotFoundException(customerId);
        }

        if(customer.getMoney() < amount) {
            throw new NotEnoughMoneyException(customer.getMoney(),amount);
        }
        Receipt receipt = new Receipt(amount,customerRepository.findById(customerId));
        customer.setPoint(receipt.getPoint());
        sendMessage(customer);

        return receipt;
    }
    public Receipt pay(long amount, Long customerId,Long point){
        System.out.println(amount);
        Customer customer = customerRepository.findById(customerId);
        if(customer.getPoint()<point){
            throw new NotEnoughPointException(point);
        }
        return this.pay(amount-point,customerId);
    }

    public boolean sendMessage(Customer customer){
        if(Objects.isNull(customer)) {
            return false;
        }
        return customer.getWantToReceive().sendMessage(customer, "");

//        customer.getMessage("Thankyou");
//
//        return true;
    }
}
