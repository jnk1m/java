package com.nhnacademy.gw1;

public class NotEnoughMoneyException extends RuntimeException  {
    NotEnoughMoneyException(long customerMoney, long amount) {
        super(String.format("Not enough money / CustomerMoney: %d,Amount: %d",customerMoney,amount));
    }
}
