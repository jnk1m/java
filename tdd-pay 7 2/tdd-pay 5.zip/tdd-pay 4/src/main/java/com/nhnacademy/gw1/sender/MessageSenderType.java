package com.nhnacademy.gw1.sender;

import com.nhnacademy.gw1.Customer;

public enum MessageSenderType implements MessageSender {
    SMS() {
        @Override
        public boolean sendMessage(Customer customer, String message) {
            String sms = customer.getReceivedDetail().getSms();
            if(sms == null) return false;
            System.out.println(customer.getCustomerId() + " " + sms);
            return true;
        }
    },
    EMAIL() {
        @Override
        public boolean sendMessage(Customer customer, String message) {
            String email = customer.getReceivedDetail().getEmail();
            if(email == null) return false;
            System.out.println(customer.getCustomerId() + " " + email);
            return true;
        }
    },
    DOORAY() {
        @Override
        public boolean sendMessage(Customer customer, String message) {
            String dooray = customer.getReceivedDetail().getSms();
            if(dooray == null) return false;
            System.out.println(customer.getCustomerId() + " " + dooray);
            return true;
        }
    },
}
