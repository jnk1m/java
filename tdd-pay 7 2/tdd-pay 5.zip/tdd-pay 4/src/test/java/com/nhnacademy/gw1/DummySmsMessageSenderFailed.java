package com.nhnacademy.gw1;

import com.nhnacademy.gw1.sender.MessageSender;

public class DummySmsMessageSenderFailed implements MessageSender {
    @Override
    public boolean sendMessage(Customer customer, String message) {
        return false;
    }
}
