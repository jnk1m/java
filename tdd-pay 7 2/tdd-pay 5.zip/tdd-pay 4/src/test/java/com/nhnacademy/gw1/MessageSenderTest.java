package com.nhnacademy.gw1;

public class MessageSenderTest {
}
