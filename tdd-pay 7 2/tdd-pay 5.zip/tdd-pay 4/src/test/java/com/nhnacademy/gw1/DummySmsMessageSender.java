package com.nhnacademy.gw1;

import com.nhnacademy.gw1.sender.MessageSender;

public class DummySmsMessageSender implements MessageSender {
    @Override
    public boolean sendMessage(Customer customer, String message) {
        return true;
    }
}
