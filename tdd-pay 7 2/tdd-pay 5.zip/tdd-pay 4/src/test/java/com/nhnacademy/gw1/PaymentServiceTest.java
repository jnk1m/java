package com.nhnacademy.gw1;

import com.nhnacademy.gw1.domain.CustomerReceivedDetail;
import com.nhnacademy.gw1.sender.MessageSenderType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

class PaymentServiceTest {
    // SUT
    PaymentService service;
    // DOC
    CustomerRepository repository;
    Customer testCustomer;


    @BeforeEach
    void setUp() {
        repository = mock(CustomerRepository.class);

        service = new PaymentService(repository);

        testCustomer = new Customer(123123L);
        testCustomer.setMoney(100000L);
        testCustomer.setPoint(10000L);
        testCustomer.setWantToReceive(MessageSenderType.SMS);
        CustomerReceivedDetail detail = new CustomerReceivedDetail();
        detail.setDooray("dooray");
        detail.setEmail("dooray");
        detail.setSms("dooray");
        testCustomer.setReceivedDetail(detail);
    }

    @Test
    void pay_notFoundCustomer_thenThrowCustomerNotFoundException() {
        long amount = 10_000L;
        Long customerId = 3423432L;

        when(repository.findById(customerId)).thenReturn(null);

        assertThatThrownBy(() -> service.pay(amount, customerId))
                .isInstanceOf(CustomerNotFoundException.class)
                .hasMessageContaining("Not found customer", customerId.toString());
    }

    @Test
    void pay_invalidAmount_thenThrowInvalidAmountException() {
        // TODO: Keep going~
        long amount = -123L;
        Long customerId = 123135L;
//        when(service.pay(amount, customerId)).thenReturn();

        assertThatThrownBy(()-> service.pay(amount, customerId)).isInstanceOf(InvalidAmountException.class)
                .hasMessageContaining("Invalid Amount", amount);
    }

    @Test
    void pay_thenReturnReceipt_whenSuccess(){
        long amount = 10_000L;
        Long customerId = 1212121L;

        when(repository.findById(customerId)).thenReturn(testCustomer);

        assertThat(service.pay(amount, customerId)).isInstanceOf(Receipt.class);
    }

    @Test
    void pay_pointSave_toCustomer(){
        long amount = 1000L;
        Long customerId = 123123L;

        when(repository.findById(customerId)).thenReturn(testCustomer);
        assertThat(service.pay(amount,customerId).getPoint()).isNotEqualTo(0L);
    }

    @Test
    void pay_customer_notEnoughMoney() {
        long amount = 1000L;
        Long customerId = 123123L;

        when(repository.findById(customerId)).thenReturn(testCustomer);
        testCustomer.setMoney(100L);

        assertThatThrownBy(()-> service.pay(amount, customerId)).isInstanceOf(NotEnoughMoneyException.class)
                .hasMessageContaining("Not enough money", amount);
    }
    @Test
    void pay_customer_notEnoughPoint() {
        long amount = 1000L;
        Long customerId = 123123L;

        when(repository.findById(customerId)).thenReturn(testCustomer);
        testCustomer.setPoint(10L);

        assertThatThrownBy(() -> service.pay(amount, customerId,100L)).isInstanceOf(NotEnoughPointException.class)
                .hasMessageContaining("Not Enough Point", testCustomer.getPoint());
    }

    @Test
    void pay_withPoint_success(){
        long amount = 1000L;
        Long customerId = 123123L;
        when(repository.findById(customerId)).thenReturn(testCustomer);
        assertThat(service.pay(amount,customerId,100L).getAmount()).isEqualTo(900L);
    }

    @Test
    void pay_sendMessage_whenSuccess(){
        long amount = 1000L;
        Long customerId = 123123L;
        when(repository.findById(customerId)).thenReturn(testCustomer);
        assertThat(service.pay(amount,customerId,100L).getAmount());
    }

    @Test
    void dummySmsMessageSenderSuccessTest(){
        long amount = 1000L;
        Long customerId = 123123L;
        DummySmsMessageSender dummySmsMessageSender = new DummySmsMessageSender();

        testCustomer.setWantToReceive(dummySmsMessageSender);
        assertThat(service.sendMessage(testCustomer)).isTrue();

    }

    @Test
    void dummySmsMessageSenderFailedTest(){
        long amount = 1000L;
        Long customerId = 123123L;
        DummySmsMessageSenderFailed dummySmsMessageSender = new DummySmsMessageSenderFailed();

        testCustomer.setWantToReceive(dummySmsMessageSender);
        when(repository.findById(customerId)).thenReturn(testCustomer);
        assertThat(service.pay(amount, customerId)).isInstanceOf(Receipt.class);
    }

    @Test
    void messageSenderSendTest(){
        long amount = 1000L;
        Long customerId = 123123L;

        
    }
}